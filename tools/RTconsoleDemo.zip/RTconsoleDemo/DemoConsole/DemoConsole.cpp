// DemoConsole.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <windows.h>

int main(int argc, char* argv[])
{
	for (int i = 0; i < 100; i++)
	{
		for (int j = 0; j < i; j++)
			printf(".");
		printf("%d\n", i);
		Sleep(50);
	}
	return 0;
}

